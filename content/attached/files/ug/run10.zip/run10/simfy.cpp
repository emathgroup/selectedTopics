#include <stdio.h>
#include <ctype.h>
#include <string>
#include <set>
#define MAXS 1024
char line[MAXS];
int main()
{
	std::set<std::string> allnums;
	while(fgets(line,MAXS,stdin)){
		char *p=line;char *q;
		while(*p!='['&&*p!='\0')p++;
		if(*p=='\0'){
			fprintf(stderr, "End of line\n");
			continue;
		}
		p++;
start_a_number:
		while(isspace(*p))p++;
		q=p;
		while(isdigit(*q)||*q=='/')q++;
		std::string s(p,q-p);
		allnums.insert(s);
		if(*q!=']'&&*q!='\0'){
			p=q+1;
			goto start_a_number;
		}
	}
	std::set<std::string>::iterator it;
	for(it=allnums.begin();it!=allnums.end();++it){
		printf("%s\n",it->c_str());
	}
	return 0;
}
