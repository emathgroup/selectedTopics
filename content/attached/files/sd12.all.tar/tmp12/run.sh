#!/bin/bash
for i in {9..9}
do
	tar xzvf sd12.9.$i.tgz
	../filt3 1>sd12/filt3.out 2>sd12/filt3.err
	mv result.all sd12/
	../norm4 sd12/result.all >sd12/result.n
	sort -u sd12/result.n > sd12/result.ns
	tar czvf sd12.9.$j.tgz sd12
	rm -rf sd12
done
